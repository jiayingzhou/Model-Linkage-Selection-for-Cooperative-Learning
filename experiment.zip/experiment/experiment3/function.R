#   Y = beta1 X + beta2 Z + C
options(digits = 22)
library(partitions)
library(adaptMCMC)


cummean <- function(x)
  cumsum(x) / seq_along(x)


# marginal function of y
marg_index = function(all_dat_x1,
                      all_dat_x2,
                      all_dat_x3,
                      all_dat_x4,
                      all_dat_x5,
                      all_dat_x6,
                      all_dat_x7,
                      all_dat_x8,
                      all_dat_x9,
                      all_dat_y,
                      colname) {
  burnin = 1:5000
  num = 15000
  p.log_post <- function(param) {
    # likelihood
    l <- 0
    
    for (i in 1:10) {
      if (colnames(all_dat_y)[i] %in% colname)
        l <-
          l + sum(dbinom(
            as.vector(na.omit(all_dat_y[, i])),
            log = T,
            size = 1,
            prob = 1 / (1 + exp(
              -(
                param[1] * na.omit(all_dat_x1[, i]) + param[2] * na.omit(all_dat_x2[, i]) +
                  param[3] * na.omit(all_dat_x3[, i])+param[4] * na.omit(all_dat_x4[, i]) +
                  param[5] * na.omit(all_dat_x5[, i]) + param[6] * na.omit(all_dat_x6[, i]) +
                  param[7] * na.omit(all_dat_x7[, i])+param[8] * na.omit(all_dat_x8[, i]) +
                  param[9] * na.omit(all_dat_x9[, i])+
                  param[10]
              )
            ))
          ))
    }
    
    # prior
    prior_mean = rep(0, 10)
    for (i in 1:10)
      l <- l + dnorm(param[i],
                     mean = prior_mean[i],
                     sd = 4,
                     log = T)
    l
  }
  res <-
    MCMC(
      p.log_post,
      n = num,
      init = rep(0, 10),
      adapt = TRUE,
      acc.rate = 0.3
    )
  sam <- res$samples
  
  sam <- sam[-burnin, ]
  
  marg = 0
  for (i in 1:10) {
    fn = as.vector(sam[, 1] %o% na.omit(all_dat_x1[, i])) + as.vector(sam[, 2] %o%
                                                                        na.omit(all_dat_x2[, i])) + as.vector(sam[, 3] %o% na.omit(all_dat_x3[, i])) +
      as.vector(sam[, 4] %o% na.omit(all_dat_x4[, i])) + as.vector(sam[, 5] %o% na.omit(all_dat_x5[, i]))+as.vector(sam[,6]%o%na.omit(all_dat_x6[,i]))+as.vector(sam[,7]%o%na.omit(all_dat_x7[,i]))+as.vector(sam[,8]%o%na.omit(all_dat_x8[,i]))+as.vector(sam[,9]%o%na.omit(all_dat_x9[,i]))+as.vector(sam[,10]%o%rep(1,length(all_dat_y[,i])))
    if((colnames(all_dat_y)[i])%in%colname) marg = marg+sum(dbinom(rep(as.vector(na.omit(all_dat_y[,i])),each=10000), size = 1, log=T, prob=1/(1+exp(-fn))))
  }
  
  res = (marg) / 10000
  result = list()
  result[[1]] = c(1, res)
  result[[2]] = sam
  return(result)
}








##########       Greedy V2        ##############
greedy = function(seed, len, percent) {
  wpbc = read.csv("breast-cancer-wisconsin.data",
  header = F)
  wpbc$V11 = (wpbc$V11 - 2) / 2
  wpbc = wpbc[, -1]
  goodindex = which(wpbc$V7!=levels(wpbc$V7)[1])
  wpbc = wpbc[goodindex,]
  wpbc$V7 = as.numeric(wpbc$V7)-1
  wpbc = na.omit(wpbc)
  
  
  
  
  len_long = c()
  
  samp = sample(nrow(wpbc))
  
  spam = wpbc[samp, ]
  
  n.test = 100
  test = spam[1:n.test, ]
  
  train = spam[-(1:n.test), ]
  node1 = train[1:len, ]
  node2 = train[(len + 1):(2 * len), ]
  node3 = train[(2 * len + 1):(3 * len), ]
  node4 = train[(3 * len + 1):(4 * len), ]
  node5 = train[(4 * len + 1):(5 * len), ]
  node6 = train[(5 * len + 1):(6 * len), ]
  node7 = train[(6 * len + 1):(7 * len), ]
  node8 = train[(7 * len + 1):(8 * len), ]
  node9 = train[(8 * len + 1):(9 * len), ]
  node10 = train[(9 * len + 1):(10 * len), ]
  contamine = as.integer(len * percent)  # contamine node10
  node10[1:contamine, ]$V11 = ifelse(node10[1:contamine, ]$V11 == 1, 0, 1)
  
  Y1 = node1$V11
  X1 = node1[, ]
  
  Y2 = node2$V11
  X2 = node2[, ]
  
  Y3 = node3$V11
  X3 = node3[, ]
  
  Y4 = node4$V11
  X4 = node4[, ]
  
  Y5 = node5$V11
  X5 = node5[, ]
  
  Y6 = node6$V11
  X6 = node6[, ]
  
  Y7 = node7$V11
  X7 = node7[, ]
  
  Y8 = node8$V11
  X8 = node8[, ]
  
  Y9 = node9$V11
  X9 = node9[, ]
  
  Y10 = node10$V11
  X10 = node10[, ]
  
  all_dat_x1 = data.frame(
    B.1 = X1[, 1],
    B.2 = X2[, 1],
    B.3 = X3[, 1],
    B.4 = X4[, 1],
    B.5 = X5[, 1],
    B.6 = X6[, 1],
    B.7 = X7[, 1],
    B.8 = X8[, 1],
    B.9 = X9[, 1],
    B.10 = X10[, 1]
  )
  all_dat_x2 = data.frame(
    B.1 = X1[, 2],
    B.2 = X2[, 2],
    B.3 = X3[, 2],
    B.4 = X4[, 2],
    B.5 = X5[, 2],
    B.6 = X6[, 2],
    B.7 = X7[, 2],
    B.8 = X8[, 2],
    B.9 = X9[, 2],
    B.10 = X10[, 2]
  )
  all_dat_x3 = data.frame(
    B.1 = X1[, 3],
    B.2 = X2[, 3],
    B.3 = X3[, 3],
    B.4 = X4[, 3],
    B.5 = X5[, 3],
    B.6 = X6[, 3],
    B.7 = X7[, 3],
    B.8 = X8[, 3],
    B.9 = X9[, 3],
    B.10 = X10[, 3]
  )
  all_dat_x4 = data.frame(
    B.1 = X1[, 4],
    B.2 = X2[, 4],
    B.3 = X3[, 4],
    B.4 = X4[, 4],
    B.5 = X5[, 4],
    B.6 = X6[, 4],
    B.7 = X7[, 4],
    B.8 = X8[, 4],
    B.9 = X9[, 4],
    B.10 = X10[, 4]
  )
  all_dat_x5 = data.frame(
    B.1 = X1[, 5],
    B.2 = X2[, 5],
    B.3 = X3[, 5],
    B.4 = X4[, 5],
    B.5 = X5[, 5],
    B.6 = X6[, 5],
    B.7 = X7[, 5],
    B.8 = X8[, 5],
    B.9 = X9[, 5],
    B.10 = X10[, 5]
  )
  all_dat_x6 = data.frame(
    B.1 = X1[, 6],
    B.2 = X2[, 6],
    B.3 = X3[, 6],
    B.4 = X4[, 6],
    B.5 = X5[, 6],
    B.6 = X6[, 6],
    B.7 = X7[, 6],
    B.8 = X8[, 6],
    B.9 = X9[, 6],
    B.10 = X10[, 6]
  )
  all_dat_x7 = data.frame(
    B.1 = X1[, 7],
    B.2 = X2[, 7],
    B.3 = X3[, 7],
    B.4 = X4[, 7],
    B.5 = X5[, 7],
    B.6 = X6[, 7],
    B.7 = X7[, 7],
    B.8 = X8[, 7],
    B.9 = X9[, 7],
    B.10 = X10[, 7]
  )
  all_dat_x8 = data.frame(
    B.1 = X1[, 8],
    B.2 = X2[, 8],
    B.3 = X3[, 8],
    B.4 = X4[, 8],
    B.5 = X5[, 8],
    B.6 = X6[, 8],
    B.7 = X7[, 8],
    B.8 = X8[, 8],
    B.9 = X9[, 8],
    B.10 = X10[, 8]
  )
  all_dat_x9 = data.frame(
    B.1 = X1[, 9],
    B.2 = X2[, 9],
    B.3 = X3[, 9],
    B.4 = X4[, 9],
    B.5 = X5[, 9],
    B.6 = X6[, 9],
    B.7 = X7[, 9],
    B.8 = X8[, 9],
    B.9 = X9[, 9],
    B.10 = X10[,9]
  )
  all_dat_y = data.frame(
    B.1 = Y1,
    B.2 = Y2,
    B.3 = Y3,
    B.4 = Y4,
    B.5 = Y5,
    B.6 = Y6,
    B.7 = Y7,
    B.8 = Y8,
    B.9 = Y9,
    B.10 = Y10
  )
  
  num.modules = ncol(all_dat_x1)
  ptm <- proc.time()
  #  Here the first column of data is module 1 , is our data.
  marg.list = list()
  samp.list = list()
  
  for (i in 1:num.modules) {
    result = marg_index(
      all_dat_x1,
      all_dat_x2,
      all_dat_x3,
      all_dat_x4,
      all_dat_x5,
      all_dat_x6,
      all_dat_x7,
      all_dat_x8,
      all_dat_x9,
      all_dat_y,
      colnames(all_dat_y)[i]
    )
    marg.list[[i]] = result[[1]]
    samp.list[[i]] = result[[2]]
  }
  
  for (i in 2:num.modules) {
    result = marg_index(
      all_dat_x1,
      all_dat_x2,
      all_dat_x3,
      all_dat_x4,
      all_dat_x5,
      all_dat_x6,
      all_dat_x7,
      all_dat_x8,
      all_dat_x9,
      all_dat_y,
      colnames(all_dat_y)[c(1, i)]
    )
    marg.list[[i + num.modules - 1]] = result[[1]]
    samp.list[[i + num.modules - 1]] = result[[2]]
  }
  
  start_point_combine = c(1, rep(0, num.modules - 1))
  for (i in 2:num.modules) {
    r = marg.list[[i + num.modules - 1]][2] - (marg.list[[1]][2] + marg.list[[i]][2])
    if (r > 0)
      start_point_combine[i] = 1
  }
  
  true_samp = marg_index(
    all_dat_x1,
    all_dat_x2,
    all_dat_x3,
    all_dat_x4,
    all_dat_x5,
    all_dat_x6,
    all_dat_x7,
    all_dat_x8,
    all_dat_x9,
    all_dat_y,
    colnames(all_dat_y)[which(start_point_combine == 1)]
  )[[2]]
  samp1 = samp.list[[1]]
  samp1f = samp.list[[2 * num.modules - 1]]
  
  time = proc.time() - ptm
  
  # set test data predictor as matrix
  test.pred.mat = as.matrix(test)[, 1:9]
  
  
  coef1 = colMeans(samp1)
  coef_true = colMeans(true_samp)
  coef13 = colMeans(samp1f)
  ##   Compare the prediction accuracy
  
  y1_raw = test.pred.mat %*% coef1[1:9] + coef1[10]
  y1 = ifelse(y1_raw > 0, 1, 0)
  
  yt_raw = test.pred.mat %*% coef_true[1:9] + coef_true[10]
  yt = ifelse(yt_raw > 0, 1, 0)
  
  y13_raw = test.pred.mat %*% coef13[1:9] + coef13[10]
  y13 = ifelse(y13_raw > 0, 1, 0)
  
  acc1 = length(which(test$V11 - y1 == 0)) / length(y1)
  acc_t = length(which(test$V11 - yt == 0)) / length(yt)
  acc13 = length(which(test$V11 - y13 == 0)) / length(y13)
  
  result = list()
  result[[1]] = start_point_combine
  result[[2]] = time
  result[[3]] = c(acc1, acc_t, acc13)

  return(result)
}
