#!/bin/bash
 for i in {1..1}
    do
  for j in {1..1}
      do
qsub -v arg1=$i,arg2=$j,arg3=1 -o /dev/null -e /dev/null runsim.pbs

      done
   done
