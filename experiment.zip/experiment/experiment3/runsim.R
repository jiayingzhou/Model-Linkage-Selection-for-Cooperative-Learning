source("function.R")
args <- commandArgs(TRUE)
seed <- as.numeric(args[[1]])
len <- as.numeric(args[[2]])
percent <- as.numeric(args[[3]])
len = 25*len
#j = seed
for (j in (10*seed-9):(10*seed)) {
  res = greedy(seed=j,len=len,percent=percent)
  save(res,file = paste("greedy/seed",j,"percent",percent,"number",len,".RData",sep=""))
}

