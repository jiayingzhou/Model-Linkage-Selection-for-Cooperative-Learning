

################
result = list()
result[[1]] = matrix(NA,200,5)
result[[2]] = matrix(NA,200,5)
result[[3]] = matrix(NA,200,5)



acc1 = matrix(NA,200,5)
acc12 = matrix(NA,200,5)
acc13 = matrix(NA,200,5)
l = 0
for(j in 1:100)
{
  for(i in seq(25,125,25))
  {
    load(paste("/Users/jiayingzhou/Desktop/adult/greedy/seed",j,"percent",1,"number",i,".RData",sep = ""))
    result[[1]][j,i/25] = 0
      if((sum(res[[1]]-c(1,1,3))^2 == 0))  result[[1]][j,i/25] = 1
    acc1[j,i/25] = res[[3]][1]
    acc12[j,i/25] = res[[3]][2]
    acc13[j,i/25] = res[[3]][3]
   
    }
}

for(j in 101:200)
{
  for(i in seq(25,125,25))
  {
    load(paste("/Users/jiayingzhou/Desktop/adult/greedy2/seed",j,"percent",1,"number",i,".RData",sep = ""))
    result[[1]][j,i/25] = 0
    if((sum(res[[1]]-c(1,1,3))^2 == 0))  result[[1]][j,i/25] = 1
    acc1[j,i/25] = res[[3]][1]
    acc12[j,i/25] = res[[3]][2]
    acc13[j,i/25] = res[[3]][3]
    
  }
}

a1 = colMeans(result[[1]])
b1 = colMeans(acc1)
c1 = colMeans(acc12)
d1 = colMeans(acc13)




###  Larger data set
result = list()
result[[1]] = matrix(NA,200,5)
result[[2]] = matrix(NA,200,5)
result[[3]] = matrix(NA,200,5)



acc1 = matrix(NA,200,5)
acc12 = matrix(NA,200,5)
acc13 = matrix(NA,200,5)
l = 0

for(i in seq(25,100,25))
  {
    for(j in 1:200)
    {
    load(paste("/Users/jiayingzhou/Desktop/adult/greedy3/seed",j,"percent",1,"number",i+125,".RData",sep = ""))
    result[[1]][j,i/25] = 0
    if((sum(res[[1]]-c(1,1,3))^2 == 0))  result[[1]][j,i/25] = 1
    acc1[j,i/25] = res[[3]][1]
    acc12[j,i/25] = res[[3]][2]
    acc13[j,i/25] = res[[3]][3]
    
  }
}

a2 = colMeans(result[[1]])
b2 = colMeans(acc1)
c2 = colMeans(acc12)
d2 = colMeans(acc13)

num = seq(25,225,25)
select = c(a1,a2)[-10]
acc1 = c(b1,b2)[-10]
acc12 = c(c1,c2)[-10]
acc13 = c(d1,d2)[-10]

df = data.frame(num,select,acc1,acc12,acc13)
write.csv(df,file = "/Users/jiayingzhou/Desktop/adult/adult.csv", row.names = F)



par(mfrow = c(1,1))
x<-1:5; y1=a; y2=b; y3 = c; y4 = d;
yy = c(0.4,1,0.4,1,1)
plot(x, yy, type="b", pch=19, col="white", xlab="x", ylab="y")
# Add a line
#lines(x, y1, pch=18, col="brown", type="b", lty=2)
lines(x, y2, pch=18, col="blue", type="b", lty=2)
lines(x, y3, pch=18, col="black", type="b",  lty=1)
lines(x, y4, pch=18, col="grey",  lty=1,type="b")
# Add a legend
legend(4, 1, legend=c("Line 1", "Line 2"),
       col=c("red", "blue"), lty=1:2, cex=0.8)






####   Read Result from WPBC      ####

acc25 = matrix(NA,200,3)

for (seed in 1:200) {
  load(paste("/Users/jiayingzhou/Desktop/wpbc/greedy2/seed",seed,"percent1number",25,".RData",sep = ""))
  acc25[seed,] = res[[3]]
}


acc50 = matrix(NA,200,3)

for (seed in 1:200) {
  load(paste("/Users/jiayingzhou/Desktop/wpbc/greedy2/seed",seed,"percent1number",50,".RData",sep = ""))
  acc50[seed,] = res[[3]]
}


colMeans(acc25)
colMeans(acc50)




