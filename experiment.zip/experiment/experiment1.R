options(digits = 22)
library(partitions)
library(MASS)


#  This function is for calculating the mean vector and sigma matrix for marginal function of y
sig_mat = function(X, sigma, prior_mat) {
  mean = rep(0, nrow(X))
  Sig = X %*% prior_mat %*% t(X) + diag(sigma ^ 2, nrow(X))
  result = list()
  result[[1]] = mean
  result[[2]] = Sig
  return(result)
}


##  This is the bayesian prediction function for new observation y based on old data, here X,Y are history data,
## x_new is new observations. Consider the y|y1,y2,...,yn, this will give us a conditional distribution of
# It will return  mean and variance of predictive distribution.
pred_function = function(X, Y, x_new, sigma, prior_mat) {
  pred = function(y) {
    v_x = rbind(x_new, X)
    v_y = c(y, Y)
    Sig = sig_mat(v_x, sigma, prior_mat)[[2]]
    f = -0.5 * t(v_y) %*% solve(Sig) %*% v_y
    return(f)
  }
  # ay^2+by+c
  a = (pred(1) + pred(-1)) / 2 - pred(0)
  b = (pred(1) - pred(-1)) / 2
  variance =  -1 / (2 * a)
  mu = -b / (2 * a)
  return(c(mu, variance))
}


##  This is the marginal function for data Y, here I seperate to exponential part and regular part, like a*exp(b),
## The exponential part is b, regular part is a. here I delete (2*pi)^nrow(X) because it will varnish in later calculation.
marg_index = function(x, y, sigma, prior_mat) {
  mean = rep(0, nrow(x))
  Sig = x %*% prior_mat %*% t(x) + diag(sigma ^ 2, nrow(x))
  marg_y_exp = -0.5 * t(y - mean) %*% solve(Sig) %*% (y - mean)
  marg_y_reg = 1 / sqrt(det(Sig/(sigma^2)))
  result = c(marg_y_reg, marg_y_exp)
  return(result)
}


# MAIN function
# beta: true coeefficent
# num: data size in each learner
# seed: random seed
# sigma: the variance of error in linear regression
# prior_mat: variance-covariance matrix of beta prior
# bias: The bias between coefficient value between L1 and L4
# correlation: correlation parameter between X, the laeger, corrraltion is smaller.
greedy = function(beta, num, seed, sigma, prior_mat,bias,correlation = 1000) {
  set.seed(seed)
  num.modules =  6
  p  = length(beta)
  
  corr_mat = matrix(NA, nrow = p, ncol = p)
  for (ii in 1:p) {
    for (jj in 1:p) {
      corr_mat[ii,jj] = exp(-correlation*abs(ii-jj))
    }
  }
  
  data = list()
  for (i in 1:num.modules) {
    X = mvrnorm(n=num,mu = rep(1,p),Sigma = corr_mat)
    if(i==1 ) {
      X[,1:as.integer(p/2)] = 0 
      y = X%*%beta+rnorm(num,0,sigma)
    }
    if(i==3) {
      X[,(as.integer(p/2)+1):ncol(X)] = 0 
      y = X%*%beta+rnorm(num,0,sigma)
    } 
    if(i==4) {
      X[,1:as.integer(p/2)] = 0 
      y = X%*%(beta+bias)+rnorm(num,0,sigma)
    }
    
    if(i==5) {
      X[,1:as.integer(p/2)] = 0 
      y = (X+5)^2 + rnorm(num,0,sigma)
    }
    if(i==6 ) {
      X[,1:as.integer(p/2)] = 0 
      y = X%*%beta+rnorm(num,0,sigma)
    }
    data[[i]] = cbind(X,y)
  }
  dat = rbind(data[[1]],data[[2]],data[[3]],data[[6]])
  beta_hat = coef(lm(dat[,(p+1)] ~ dat[,1:p]+0))
  
  
  dat = rbind(data[[1]])
  beta_hat = coef(lm(dat[,(p+1)] ~ dat[,1:p]+0))
  
  # First consider L1 with L2,L4,L5
  marg_index_mat = matrix(NA,100,7)
  
  for (j in 1:6) {
    x = data[[j]][,1:p]
    y = data[[j]][,(p+1)]
    marg = marg_index(x, y, sigma, prior_mat) 
    marg_index_mat[j,1:2] = marg
  }
  for (k in c(2,4,5,6)) {
    x = rbind(data[[1]][,1:p],data[[k]][,1:p])
    y = c(data[[1]][,(p+1)],data[[k]][,(p+1)])
    marg = marg_index(x, y, sigma, prior_mat) 
    marg_index_mat[k+6,1:2] = marg
  }
  
  compare.result = c(1,0,0,0,0,0)
  for (jj in c(2,4,5,6)) {
    r = log(marg_index_mat[jj+6,1])-(log(marg_index_mat[1,1])+log(marg_index_mat[jj,1]))+marg_index_mat[jj+6,2]-(marg_index_mat[1,2]+marg_index_mat[jj,2])
    if(r>0) compare.result[jj] = 1
  }
  if(compare.result[2]==1){
    
    x = rbind(data[[2]][,1:p],data[[3]][,1:p])
    y = c(data[[2]][,(p+1)],data[[3]][,(p+1)])
    marg23 = marg_index(x, y, sigma, prior_mat) 
    r = log(marg23[1])-(log(marg_index_mat[2,1])+log(marg_index_mat[3,1]))+marg23[2]-(marg_index_mat[2,2]+marg_index_mat[3,2])
    if(r>0) compare.result[3] = 1
  }
  
  
  result = compare.result
  # prediction
  n.test = 50
  X_N = mvrnorm(n= n.test,mu = rep(1,p),Sigma = corr_mat)
  X_N[,1:as.integer(p/2)] = 0
  Y_N = X_N%*%beta+rnorm(n.test,0,sigma)
  
  X_1 = data[[1]][,1:p]
  Y_1 = data[[1]][,p+1]
  
  X_14 = rbind(data[[1]][,1:p],data[[4]][,1:p])
  Y_14 = c(data[[1]][,(p+1)],data[[4]][,(p+1)])
  
  X_t = data[[1]][,1:p]
  Y_t = data[[1]][,p+1]
  for (kk in 2:6) {
    if(compare.result[kk] == 1){
      X_t = rbind(X_t,data[[kk]][,1:p])
      Y_t = c(Y_t,data[[kk]][,p+1])
    }
  }
  pred_variance1 = rep(NA,n.test)
  pred_variancet = rep(NA,n.test)
  pred_variance14 = rep(NA,n.test)
  for (i in 1:n.test) pred_variance1[i]  = pred_function(X_1, Y_1, x_new = X_N[i,], sigma, prior_mat)[2]
  for (i in 1:n.test) pred_variancet[i]  = pred_function(X_t, Y_t, x_new = X_N[i,], sigma, prior_mat)[2]
  for (i in 1:n.test) pred_variance14[i]  = pred_function(X_14, Y_14, x_new = X_N[i,], sigma, prior_mat)[2]
  length1 =  qnorm(0.975,0,sd = sqrt(pred_variance1))*2
  lengtht =  qnorm(0.975,0,sd = sqrt(pred_variancet))*2
  length14 =  qnorm(0.975,0,sd = sqrt(pred_variance14))*2
  result = list()
  result[[1]] = compare.result
  result[[2]]  = c(mean(lengtht),mean(length1),mean(length14))
  return(result)
}



####   RUN #####

acc = rep(NA,6)
acc_pred = matrix(NA, nrow = 6, ncol = 3)
for (number in 1:6) {
  iterat = 200
  acc_count = 0
  acc_compare = matrix(NA,iterat,3)
  for (i in 1:iterat) {
    result = greedy(beta = rep(0.3,15),25*number,seed = i,sigma = 3,prior_mat = diag(4,15),.3)
    if(sum((result[[1]]-c(1,1,1,0,0,1))^2)==0) acc_count = acc_count+1
    acc_compare[i,] = result[[2]]
    print(result[[1]])
  }
  acc[number] = acc_count/iterat
  acc_pred[number,] =  colMeans(acc_compare)
  
}









