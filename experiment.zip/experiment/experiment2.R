#   Y = beta1 X + beta2 Z + C
options(digits = 22)
library(partitions)
library(adaptMCMC)


cummean <- function(x)
  cumsum(x) / seq_along(x)



#   The marginal function of y, we use Lemma 1 (iv) to estimate the marginal function.
marg_index = function(all_dat_x1,
                      all_dat_x2,
                      all_dat_x3,
                      all_dat_x4,
                      all_dat_x5,
                      all_dat_x6,
                      all_dat_x7,
                      all_dat_x8,
                      all_dat_x9,
                      all_dat_y,
                      colname) {
  index = NA
  for (i in 1:length(colname)) {
    index = c(index,which(colnames(all_dat_y)==colname[i]))
  }
  index = index[-1]
  
  y = as.vector(as.matrix(all_dat_y[,index]))
  x1 = as.vector(as.matrix(all_dat_x1[,index]))
  x2 = as.vector(as.matrix(all_dat_x2[,index]))
  x3 = as.vector(as.matrix(all_dat_x3[,index]))
  x4 = as.vector(as.matrix(all_dat_x4[,index]))
  x5 = as.vector(as.matrix(all_dat_x5[,index]))
  x6 = as.vector(as.matrix(all_dat_x6[,index]))
  x7 = as.vector(as.matrix(all_dat_x7[,index]))
  x8 = as.vector(as.matrix(all_dat_x8[,index]))
  x9 = as.vector(as.matrix(all_dat_x9[,index]))
  X = cbind(x1,x2,x3,x4,x5,x6,x7,x8,x9)
  beta_hat =  coef(glm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+0,family = "binomial"))
  len = nrow(X)
  p = length(beta_hat)
  Jn = matrix(NA,nrow = length(beta_hat),ncol = length(beta_hat))
  for (ii in 1:length(beta_hat)) {
    for (jj in 1:length(beta_hat)) {
      second_differential = 0
      for (kk in 1:length(y)) {
        second_differential = second_differential+exp(X[kk,]%*%beta_hat)*X[kk,jj]*X[kk,ii]/(1+exp(X[kk,]%*%beta_hat))^2
      }
      Jn[ii,jj] = second_differential
    }
    
  }
  log_xi = -1/2*log(det(Jn/len))-p/2*log(len)
  log_pi_beta = sum(dnorm(beta_hat,mean = rep(0,p),sd = 4, log = T))
  log_likelihood = sum(dbinom(y, size = 1, prob = 1/(1+exp(-X%*%beta_hat)),log = T))
  log_marg = p/2*log(2*pi) + log_pi_beta + log_likelihood + log_xi
  return(log_marg)
}


# GREEDY algorithm
# seed: random seed
# len: data size in each learner

greedy = function(seed, len) {
  beta = seq(-.8,1.6,0.3)
  bias = -beta
  
  set.seed(seed)
  
  X1 = matrix(runif(len*9,-1,1),len,9)
  Y1 = rbinom(len,1,prob = 1/(1+exp(-X1%*%beta)))
  
  X2 = matrix(runif(len*9,-1,1),len,9)
  Y2 = rbinom(len,1,prob = 1/(1+exp(-X2%*%beta)))
  
  X3 = matrix(runif(len*9,-1,1),len,9)
  Y3 = rbinom(len,1,prob = 1/(1+exp(-X3%*%beta)))
  
  X4 = matrix(runif(len*9,-1,1),len,9)
  Y4 = rbinom(len,1,prob = 1/(1+exp(-X4%*%beta)))
  
  X5 = matrix(runif(len*9,-1,1),len,9)
  Y5 = rbinom(len,1,prob = 1/(1+exp(-X5%*%(beta+bias))))
  
  
  
  all_dat_x1 = data.frame(
    B.1 = X1[, 1],
    B.2 = X2[, 1],
    B.3 = X3[, 1],
    B.4 = X4[, 1],
    B.5 = X5[, 1]
    
  )
  all_dat_x2 = data.frame(
    B.1 = X1[, 2],
    B.2 = X2[, 2],
    B.3 = X3[, 2],
    B.4 = X4[, 2],
    B.5 = X5[, 2]
  )
  all_dat_x3 = data.frame(
    B.1 = X1[, 3],
    B.2 = X2[, 3],
    B.3 = X3[, 3],
    B.4 = X4[, 3],
    B.5 = X5[, 3]
  )
  all_dat_x4 = data.frame(
    B.1 = X1[, 4],
    B.2 = X2[, 4],
    B.3 = X3[, 4],
    B.4 = X4[, 4],
    B.5 = X5[, 4]
  )
  all_dat_x5 = data.frame(
    B.1 = X1[, 5],
    B.2 = X2[, 5],
    B.3 = X3[, 5],
    B.4 = X4[, 5],
    B.5 = X5[, 5]
  )
  all_dat_x6 = data.frame(
    B.1 = X1[, 6],
    B.2 = X2[, 6],
    B.3 = X3[, 6],
    B.4 = X4[, 6],
    B.5 = X5[, 6]
  )
  all_dat_x7 = data.frame(
    B.1 = X1[, 7],
    B.2 = X2[, 7],
    B.3 = X3[, 7],
    B.4 = X4[, 7],
    B.5 = X5[, 7]
  )
  all_dat_x8 = data.frame(
    B.1 = X1[, 8],
    B.2 = X2[, 8],
    B.3 = X3[, 8],
    B.4 = X4[, 8],
    B.5 = X5[, 8]
  )
  all_dat_x9 = data.frame(
    B.1 = X1[, 9],
    B.2 = X2[, 9],
    B.3 = X3[, 9],
    B.4 = X4[, 9],
    B.5 = X5[, 9]
  )
  all_dat_y = data.frame(
    B.1 = Y1,
    B.2 = Y2,
    B.3 = Y3,
    B.4 = Y4,
    B.5 = Y5
  )
  
  num.modules = ncol(all_dat_x1)
  ptm <- proc.time()
  ###  Here the first column of data is module 1 , is our data.
  marg.list = list()
  samp.list = list()
  
  for (i in 1:num.modules) {
    result = marg_index(
      all_dat_x1,
      all_dat_x2,
      all_dat_x3,
      all_dat_x4,
      all_dat_x5,
      all_dat_x6,
      all_dat_x7,
      all_dat_x8,
      all_dat_x9,
      all_dat_y,
      colnames(all_dat_y)[i]
    )
    marg.list[[i]] = result
  }
  
  ####    We should start revising here         #######
  for (i in 2:num.modules) {
    result = marg_index(
      all_dat_x1,
      all_dat_x2,
      all_dat_x3,
      all_dat_x4,
      all_dat_x5,
      all_dat_x6,
      all_dat_x7,
      all_dat_x8,
      all_dat_x9,
      all_dat_y,
      colnames(all_dat_y)[c(1, i)]
    )
    marg.list[[i + num.modules - 1]] = result
  }
  
  start_point_combine = c(1, rep(0, num.modules - 1))
  for (i in 2:num.modules) {
    r = marg.list[[i + num.modules - 1]] - (marg.list[[1]] + marg.list[[i]])
    if (r > 0)
      start_point_combine[i] = 1
  }
  
  
  #print(compare.result)
  time = proc.time() - ptm
  
  # test data predictor as matrix
  index = 1
  y = as.vector(as.matrix(all_dat_y[,index]))
  x1 = as.vector(as.matrix(all_dat_x1[,index]))
  x2 = as.vector(as.matrix(all_dat_x2[,index]))
  x3 = as.vector(as.matrix(all_dat_x3[,index]))
  x4 = as.vector(as.matrix(all_dat_x4[,index]))
  x5 = as.vector(as.matrix(all_dat_x5[,index]))
  x6 = as.vector(as.matrix(all_dat_x6[,index]))
  x7 = as.vector(as.matrix(all_dat_x7[,index]))
  x8 = as.vector(as.matrix(all_dat_x8[,index]))
  x9 = as.vector(as.matrix(all_dat_x9[,index]))
  X = cbind(x1,x2,x3,x4,x5,x6,x7,x8,x9)
  coef1 =  coef(glm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+0,family = "binomial"))
  
  index = c(1,5)
  y = as.vector(as.matrix(all_dat_y[,index]))
  x1 = as.vector(as.matrix(all_dat_x1[,index]))
  x2 = as.vector(as.matrix(all_dat_x2[,index]))
  x3 = as.vector(as.matrix(all_dat_x3[,index]))
  x4 = as.vector(as.matrix(all_dat_x4[,index]))
  x5 = as.vector(as.matrix(all_dat_x5[,index]))
  x6 = as.vector(as.matrix(all_dat_x6[,index]))
  x7 = as.vector(as.matrix(all_dat_x7[,index]))
  x8 = as.vector(as.matrix(all_dat_x8[,index]))
  x9 = as.vector(as.matrix(all_dat_x9[,index]))
  X = cbind(x1,x2,x3,x4,x5,x6,x7,x8,x9)
  coef15 =  coef(glm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+0,family = "binomial"))
  
  index = which(start_point_combine==1)
  y = as.vector(as.matrix(all_dat_y[,index]))
  x1 = as.vector(as.matrix(all_dat_x1[,index]))
  x2 = as.vector(as.matrix(all_dat_x2[,index]))
  x3 = as.vector(as.matrix(all_dat_x3[,index]))
  x4 = as.vector(as.matrix(all_dat_x4[,index]))
  x5 = as.vector(as.matrix(all_dat_x5[,index]))
  x6 = as.vector(as.matrix(all_dat_x6[,index]))
  x7 = as.vector(as.matrix(all_dat_x7[,index]))
  x8 = as.vector(as.matrix(all_dat_x8[,index]))
  x9 = as.vector(as.matrix(all_dat_x9[,index]))
  X = cbind(x1,x2,x3,x4,x5,x6,x7,x8,x9)
  coeft =  coef(glm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+0,family = "binomial"))
  
  X.test = 100
  test.X = matrix(runif(X.test*9,-1,1),X.test,9)
  test.Y= rbinom(X.test,1,prob = 1/(1+exp(-test.X%*%beta)))
  
  y1_raw = test.X %*% coef1
  y1 = ifelse(y1_raw > 0, 1, 0)
  
  yt_raw = test.X %*% coeft
  yt = ifelse(yt_raw > 0, 1, 0)
  
  y15_raw = test.X %*% coef15
  y15 = ifelse(y15_raw > 0, 1, 0)
  
  acc1 = length(which(test.Y - y1 == 0)) / length(y1)
  acc_t = length(which(test.Y - yt == 0)) / length(yt)
  acc15 = length(which(test.Y - y15 == 0)) / length(y15)
  
  
  result = list()
  result[[1]] = start_point_combine
  result[[2]] = c(acc_t,acc1,acc15)
  return(result)
}


#  RUN 
# 200 iterations
# acc is the selection accuracy vector
# pred is the prediction accuracy output
itrat = 200
num_number = 6
acc = matrix(0, nrow = itrat, ncol = num_number)
pred = list()
for (jj in 1:num_number) {
  pred[[jj]] = matrix(NA,itrat,3)
}
for (j in 1:num_number) {
  for (i in 1:itrat) {
    print(c(j,i))
    result = greedy(i,j*50+50)
    if (sum((result[[1]]-c(1,1,1,1,0))^2)==0)  acc[i,j] = 1
    pred[[j]][i,] = result[[2]]
  }
}
