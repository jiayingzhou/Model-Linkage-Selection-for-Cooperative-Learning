iterate = 100
result = rep(NA,iterate)
acc_common = matrix(NA,iterate,4)
acc = matrix(NA,iterate,4) #single, algorithm,all
acc2 = matrix(NA,iterate,4)
count = 0
for (i in 1:iterate) {
  load(paste("/Users/jiayingzhou/Desktop/numerical_study/goodresult/feb18/greedy/", "seed", i, ".RData", sep = ""))
  result[i] = 0
  acc_common[i,] = res[[3]]
  print(res[[1]])
  if(res[[1]][3] == 1) count = count+1
  if (sum((res[[1]] - c(1, 1, 3)) ^ 2) == 0){
    result[i] = 1
    acc[i,] = res[[3]][c(1,2,3,4)]
    acc2[i,] = res[[3]][c(1,2,3,4)]
  }
  if (sum((res[[1]] - c(1, 1, 1)) ^ 2) == 0){
    
    acc[i,] = res[[3]][c(1,3,3,4)]
  }
  if (sum((res[[1]] - c(1, 2, 3)) ^ 2) == 0){
    
    acc[i,] = res[[3]][c(1,1,3,4)]
  }
  if (sum((res[[1]] - c(1, 2, 1)) ^ 2) == 0){
    
    acc[i,] = res[[3]][c(1,4,3,4)]
  }
}
mean(result)
colMeans(na.omit(acc))
colMeans(na.omit(acc_common))
sd(na.omit(acc)[,1])
sd(na.omit(acc)[,2])

