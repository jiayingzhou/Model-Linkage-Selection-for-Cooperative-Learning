#!/bin/bash
 for i in {1..1}
    do
  
qsub -v arg1=$i -o /dev/null -e /dev/null runsim.pbs


      done
   
