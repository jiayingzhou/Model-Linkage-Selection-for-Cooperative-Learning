#!/bin/bash
 for i in {1..50}
    do

qsub -v arg1=$i -o /dev/null -e /dev/null runsim.pbs


      
   done
