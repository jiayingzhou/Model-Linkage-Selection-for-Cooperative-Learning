source("function.R")
args <- commandArgs(TRUE)
seed <- as.numeric(args[[1]])


for(k in (2*seed-1):(2*seed)){
res = greedy(seed=k)
save(res,file = paste("greedy/seed",k,".RData",sep=""))
}
