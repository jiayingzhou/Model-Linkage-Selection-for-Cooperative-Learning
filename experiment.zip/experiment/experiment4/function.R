options(digits = 22)
library(partitions)
library(adaptMCMC)
library(invgamma)


delete.na <- function(DF, n = 0) {
  DF = DF[which(rowSums(is.na(DF)) <= n), ]
  return(DF)
}
cummean <- function(x)
  cumsum(x) / seq_along(x)

unique_fn = function(num.modules, num = 100) {
  cc <-
    c(1:num.modules)           # Substitute the vector for which you want partitions
  parts <- listParts(length(cc))
  out <- rapply(parts, function(ii)
    cc[ii], how = "replace")
  # Here out is all the possible partitions for modules.
  num_partition = length(out)
  
  # Now we consider all the possible partitions contains module 1
  index_mat = matrix(NA, nrow = num.modules, ncol = 1)   ###   The partition number is 2^4.
  for (i in 1:num_partition) {
    len = length(out[[i]])
    part = as.matrix(out[[i]])
    for (j in 1:len) {
      if (1 %in% part[[j]])
        index_mat = cbind(index_mat, c(part[[j]], rep(NA, num, num.modules - length(part[[j]]))))
    }
  }
  unique_mat = unique(t(index_mat))
  unique_mat = unique_mat[-1, ]
  return(unique_mat)
}




marg_index_mix = function(all_dat_y,
                          all_dat_x1,
                          all_dat_x21,
                          all_dat_x22,
                          all_dat_x23,
                          all_dat_x31,
                          all_dat_x32,
                          all_dat_x33,
                          all_dat_sigma,
                          colname) {
  ind = NA
  if (length(colname) > 1) {
    for (k in 1:length(colname))
      ind = c(ind, which(colname[k] == colnames(all_dat_x1)))
  }
  ind = ind[-1]
  if (length(colname) == 1)
    ind = which(colname == colnames(all_dat_x1))
  y = as.vector(na.omit(as.matrix(all_dat_y[, ind])))
  x1 = as.vector(na.omit(as.matrix(all_dat_x1[, ind])))
  x21 = as.vector(na.omit(as.matrix(all_dat_x21[, ind])))
  x22 = as.vector(na.omit(as.matrix(all_dat_x22[, ind])))
  x23 = as.vector(na.omit(as.matrix(all_dat_x23[, ind])))
  
  x31 = as.vector(na.omit(as.matrix(all_dat_x31[, ind])))
  x32 = as.vector(na.omit(as.matrix(all_dat_x32[, ind])))
  x33 = as.vector(na.omit(as.matrix(all_dat_x33[, ind])))
  
  sigma_index = as.vector(na.omit(as.matrix(all_dat_sigma[, ind])))
  mat = cbind(x1, x21, x22, x23, x31, x32, x33)
  for (k in 1:3)
    mat = cbind(mat, ifelse(sigma_index == (k - 1), 1, 0))
  mat = cbind(mat, y)
  
  
  
  T <- 20000   # burnin
  whole <- 35000
  samp_num <- 3000
  mu = c(0, 0, 0, 0, 0, 0, 0, 10, 10, 10)
  sigma = 10
  alpha = 2
  eta = 2
  param = matrix(NA, whole, 13)
  param[1, ] = c(0, 0, 0, 0, 0, 0, 0, 6, 6, 6, 10, 10, 10) # The parameter is beta1,beta21,beta22,beta23,beta31,beta32,beta33,beta0_1,beta0_2,beta0_3,sigma_1,sigma_2,sigma_3
  current_vec = param[1, ]
  
  for (i in 2:whole) {
    for (j in 1:10) {
      if (sum(mat[, j] ^ 2) == 0)
        param[i, j] = 0  #  Any other value is OK, to test if this line is empty
      else if (sum(mat[, j] ^ 2) != 0) {
        # error = y - current_vec[1]*x1-current_vec[2]*x21-current_vec[3]*x22-current_vec[4]*x31-current_vec[5]*x32-current_vec[6]*(1-sigma_index)-current_vec[7]*sigma_index
        error = y - mat[, 1:10] %*% current_vec[1:10]
        var = 1 / (
          sum(mat[which(sigma_index == 0), j] * mat[which(sigma_index == 0), j]) /
            current_vec[11] + sum(mat[which(sigma_index == 1), j] * mat[which(sigma_index ==
                                                                                1), j]) / current_vec[12] + sum(mat[which(sigma_index == 2), j] * mat[which(sigma_index ==
                                                                                                                                                              2), j]) / current_vec[13] + 1 / (sigma ^ 2)
        )
        mean = (
          sum(mat[which(sigma_index == 0), j] * (error[which(sigma_index == 0)] +
                                                   mat[which(sigma_index == 0), j] * current_vec[j])) / current_vec[11] + sum(mat[which(sigma_index ==
                                                                                                                                          1), j] * (error[which(sigma_index == 1)] + mat[which(sigma_index == 1), j] *
                                                                                                                                                      current_vec[j])) / current_vec[12] + sum(mat[which(sigma_index == 2), j] *
                                                                                                                                                                                                 (error[which(sigma_index == 2)] + mat[which(sigma_index == 2), j] * current_vec[j])) /
            current_vec[13] + mu[j] / (sigma ^ 2)
        ) * var
        
        param[i, j] = rnorm(n = 1,
                            mean = mean,
                            sd = sqrt(var))
        current_vec[j] = param[i, j]
      }
    }
    
    
    
    for (k in 1:3) {
      error = y - mat[, 1:10] %*% current_vec[1:10]
      aa = ifelse(sigma_index == (k - 1), 1, 0)
      index = error * aa
      
      new_alpha = alpha + length(which(aa == 1)) / 2
      new_eta = eta + sum(index * index) / 2
      param[i, k + 10] = rinvgamma(n = 1,
                                   shape = new_alpha,
                                   rate = new_eta)
      current_vec[k + 10] = param[i, k + 10]
      
    }
  }
  param = param[-(1:T), ]
  sam = param[c(1:samp_num) * 5, ]
  return(sam)
}
marg_index  = function(all_dat_y,
                       all_dat_x1,
                       all_dat_x21,
                       all_dat_x22,
                       all_dat_x23,
                       all_dat_x31,
                       all_dat_x32,
                       all_dat_x33,
                       all_dat_sigma,
                       colname) {
  ind = NA
  for (k in 1:length(colname))
    ind = c(ind, which(colname[k] == colnames(all_dat_x1)))
  ind = ind[-1]
  
  n = length(as.vector(na.omit(all_dat_y[, 1])))
  m = 2000 * n
  B = matrix(0, m, 10)
  beta = c(0, 0, 0, 0, 0, 0, 0, 10, 10, 10)
  for (i in 1:10) {
    B[, i] = rnorm(m, beta[i], 1)
  }
  Sig = matrix(0, m, 3)
  for (i in 1:3) {
    Sig[, i] = rinvgamma(m, 2, 1)
  }
  
  log_sample = rep(NA, m)
  for (i in 1:m) {
    marg = 0
    for (j in ind) {
      marg = marg + sum(
        dnorm(
          x = as.vector(na.omit(all_dat_y[, j])),
          mean = as.vector(na.omit(all_dat_x1[, j])) * B[i, 1] + as.vector(na.omit(all_dat_x21[, j])) * B[i, 2] +
            as.vector(na.omit(all_dat_x22[, j])) * B[i, 3]
          + as.vector(na.omit(all_dat_x23[, j])) * B[i, 4] + as.vector(na.omit(all_dat_x31[, j])) * B[i, 5] +
            as.vector(na.omit(all_dat_x32[, j])) * B[i, 6]
          + as.vector(na.omit(all_dat_x33[, j])) * B[i, 7] + B[i, j + 7],
          sd = sqrt(Sig[i, j]),
          log = T
        )
      )
    }
    log_sample[i] = marg
  }
  log_value = max(log_sample)
  exp_value = mean(exp(log_sample - log_value))
  
  result = list()
  result[[1]] = c(exp_value, log_value)
  result[[2]] = marg_index_mix(
    all_dat_y,
    all_dat_x1,
    all_dat_x21,
    all_dat_x22,
    all_dat_x23,
    all_dat_x31,
    all_dat_x32,
    all_dat_x33,
    all_dat_sigma,
    colname
  )
  return(result)
}

greedy = function(seed) {
  load("data/ProteinSurvival.RData")
  load("survdat.rda")
  survdat <- survdat
  surv_tumor = rownames(summary(survdat))
  data_num = rep(NA, length(surv_tumor))
  for (i in 1:length(surv_tumor))
  {
    temp_data  = ProteinSurvival[[i]]
    ProteinSurvival[[i]] = temp_data[which(temp_data$event == "1"), ]
    ProteinSurvival[[i]]$days = as.numeric(as.character(ProteinSurvival[[i]]$days))
    data_num[i] = nrow(ProteinSurvival[[i]])
  }
  # From the data number, we choose 4,7,10,11,14,15,18
  
  index = surv_tumor[c(4, 7, 10, 11, 15, 18)]
  
  
  KICH = ProteinSurvival[[which(surv_tumor == "KICH")]]  # too less, don't use it
  KIRC = ProteinSurvival[[which(surv_tumor == "KIRC")]]
  KIRP = ProteinSurvival[[which(surv_tumor == "KIRP")]]
  OV   = ProteinSurvival[[which(surv_tumor == "OV")]]
  LUAD = ProteinSurvival[[which(surv_tumor == "LUAD")]]
  UCEC   = ProteinSurvival[[which(surv_tumor == "UCEC")]]
  BRCA   = ProteinSurvival[[which(surv_tumor == "BRCA")]]
  STAD   = ProteinSurvival[[which(surv_tumor == "STAD")]]
  SARC   = ProteinSurvival[[which(surv_tumor == "SARC")]]
  CORE   = ProteinSurvival[[which(surv_tumor == "CORE")]]
  
  #  This is our third learner
  D3   = ProteinSurvival[[which(surv_tumor == "UCEC")]]
  
  factors = c(
    "PCADHERIN",
    "FOXO3A_pS318S321",
    "DIRAS3",
    "SF2",
    "RAD51",
    "GAB2",
    "HER3_pY1298",
    "CRAF_pS338"
  )
  
  
  possible = combn(factors, 3)
  
  close_vector = rep(0, ncol(possible))
  for (i in 1:ncol(possible)) {
    KIRCnew = KIRC[, c(as.vector(na.omit(match(
      possible[, i], colnames(KIRC)
    ))), 201, 202)]
    KIRCdata = KIRCnew[which(KIRCnew$event == "1"), -which(colnames(KIRCnew) ==
                                                             "event")]
    
    KIRPnew = KIRP[, c(as.vector(na.omit(match(
      possible[, i], colnames(KIRP)
    ))), 201, 202)]
    KIRPdata = KIRPnew[which(KIRPnew$event == "1"), -which(colnames(KIRPnew) ==
                                                             "event")]
    D3new = D3[, c(as.vector(na.omit(match(
      possible[, i], colnames(D3)
    ))), 201, 202)]
    D3data = D3new[which(D3new$event == "1"), -which(colnames(D3new) ==
                                                       "event")]
    i = 19
    
    
    KIRCnew = KIRC[, c(as.vector(na.omit(match(
      possible[, i], colnames(KIRC)
    ))), 201, 202)]
    KIRCdata = KIRCnew[which(KIRCnew$event == "1"), -which(colnames(KIRCnew) ==
                                                             "event")]
    
    KIRPnew = KIRP[, c(as.vector(na.omit(match(
      possible[, i], colnames(KIRP)
    ))), 201, 202)]
    KIRPdata = KIRPnew[which(KIRPnew$event == "1"), -which(colnames(KIRPnew) ==
                                                             "event")]
    
    
    # First we sample the KIRCdata
    set.seed(seed)
    samp = sample(nrow(KIRCdata))
    KIRCdata_train = KIRCdata[samp[1:20], ]
    KIRCdata_test = KIRCdata[samp[21:nrow(KIRCdata)], ]
    
    D3new = D3[, c(as.vector(na.omit(match(
      possible[, i], colnames(D3)
    ))), 201, 202)]
    D3data = D3new[which(D3new$event == "1"), -which(colnames(D3new) ==
                                                       "event")]
    
    ###   Delete NA    #####
    D3data = delete.na(D3data[1:50, ])
    KIRCdata_test = delete.na(KIRCdata_test)
    KIRCdata_train = delete.na(KIRCdata_train)
    KIRPdata = delete.na(KIRPdata)
    
    n1 = nrow(KIRCdata_train)
    n2 = nrow(KIRPdata)
    n3 = nrow(D3data)
    length = max(n1, n2, n3) + 1
    
    all_dat_y = data.frame(
      B.1 = c(log(KIRCdata_train$days), rep(NA, length - n1)),
      B.2 = c(log(KIRPdata$days), rep(NA, length - n2)),
      B.3 = c(log(D3data$days), rep(NA, length - n3))
    )
    all_dat_x1 = data.frame(
      B.1 = c(KIRCdata_train[, 1], rep(NA, length - n1)),
      B.2 = c(KIRPdata[, 1], rep(NA, length - n2)),
      B.3 = c(D3data[, 1], rep(NA, length - n3))
    )
    
    
    all_dat_x21 = data.frame(
      B.1 = c(KIRCdata_train[, 2], rep(NA, length - n1)),
      B.2 = c(rep(0, n2), rep(NA, length - n2)),
      B.3 = c(rep(0, n3), rep(NA, length - n3))
    )
    all_dat_x22 = data.frame(
      B.1 = c(rep(0, n1), rep(NA, length - n1)),
      B.2 = c(KIRPdata[, 2], rep(NA, length - n2)),
      B.3 = c(rep(0, n3), rep(NA, length - n3))
    )
    all_dat_x23 = data.frame(
      B.1 = c(rep(0, n1), rep(NA, length - n1)),
      B.2 = c(rep(0, n2), rep(NA, length - n2)),
      B.3 = c(D3data[, 2], rep(NA, length - n3))
    )
    
    all_dat_x31 = data.frame(
      B.1 = c(KIRCdata_train[, 3], rep(NA, length - n1)),
      B.2 = c(rep(0, n2), rep(NA, length - n2)),
      B.3 = c(rep(0, n3), rep(NA, length - n3))
    )
    all_dat_x32 = data.frame(
      B.1 = c(rep(0, n1), rep(NA, length - n1)),
      B.2 = c(KIRPdata[, 3], rep(NA, length - n2)),
      B.3 = c(rep(0, n3), rep(NA, length - n3))
    )
    all_dat_x33 = data.frame(
      B.1 = c(rep(0, n1), rep(NA, length - n1)),
      B.2 = c(rep(0, n2), rep(NA, length - n2)),
      B.3 = c(D3data[, 3], rep(NA, length - n3))
    )
    
    all_dat_sigma = data.frame(
      B.1 = c(rep(0, n1), rep(NA, length - n1)),
      B.2 = c(rep(1, n2), rep(NA, length - n2)),
      B.3 = c(rep(2, n3), rep(NA, length - n3))
    )
    
    
    
    num.modules = ncol(all_dat_y)
    ptm <- proc.time()
    ###  Here the first column of data is module 1 , is our data.
    marg.list = list()
    samp.list = list()
    
    for (i in 1:num.modules) {
      result = marg_index(
        all_dat_y,
        all_dat_x1,
        all_dat_x21,
        all_dat_x22,
        all_dat_x23,
        all_dat_x31,
        all_dat_x32,
        all_dat_x33,
        all_dat_sigma,
        colnames(all_dat_y)[i]
      )
      marg.list[[i]] = result[[1]]
      samp.list[[i]] = result[[2]]
    }
    
    for (i in 1:num.modules) {
      result = marg_index(
        all_dat_y,
        all_dat_x1,
        all_dat_x21,
        all_dat_x22,
        all_dat_x23,
        all_dat_x31,
        all_dat_x32,
        all_dat_x33,
        all_dat_sigma,
        colnames(all_dat_y)[-i]
      )
      marg.list[[i + 3]] = result[[1]]
      samp.list[[i + 3]] = result[[2]]
    }
    
    result = marg_index(
      all_dat_y,
      all_dat_x1,
      all_dat_x21,
      all_dat_x22,
      all_dat_x23,
      all_dat_x31,
      all_dat_x32,
      all_dat_x33,
      all_dat_sigma,
      colnames(all_dat_y)[1:num.modules]
    )
    marg.list[[7]] = result[[1]]
    samp.list[[7]] = result[[2]]
    
    
    r1 =  log(marg.list[[6]][1]) + marg.list[[6]][2] - (log(marg.list[[1]][1]) +
                                                          marg.list[[1]][2] + log(marg.list[[2]][1]) + marg.list[[2]][2]) # m12/(m1*m2)
    r2 = log(marg.list[[5]][1]) + marg.list[[5]][2] - (log(marg.list[[1]][1]) +
                                                         marg.list[[1]][2] + log(marg.list[[3]][1]) + marg.list[[3]][2]) # m13/(m1*m3)
    if (r1 > 0 && r2 > 0) {
      compare.result = c(1, 1, 1)
      true_samp = samp.list[[7]]
    }
    if (r1 > 0 && r2 < 0) {
      compare.result = c(1, 1, 3)
      true_samp = samp.list[[6]]
    }
    if (r1 < 0 && r2 > 0) {
      compare.result = c(1, 2, 1)
      true_samp = samp.list[[5]]
    }
    if (r1 < 0 && r2 < 0) {
      compare.result = c(1, 2, 3)
      true_samp = samp.list[[1]]
    }
    
    
    
    
    time = proc.time() - ptm
    
    ##   Compare the prediction accuracy
    samp1 = samp.list[[1]]
    samp12 = samp.list[[6]]
    samp123 = samp.list[[7]]
    samp13 = samp.list[[5]]
    
    coef1 = colMeans(samp1[, c(1, 2, 5, 8)])
    coef12 = colMeans(samp12[, c(1, 2, 5, 8)])
    coef123 = colMeans(samp123[, c(1, 2, 5, 8)])
    coef13 = colMeans(samp13[, c(1, 2, 5, 8)])
    
    pred1 = as.matrix(KIRCdata_test[, 1:3]) %*% coef1[1:3] + coef1[4]
    pred12 = as.matrix(KIRCdata_test[, 1:3]) %*% coef12[1:3] + coef12[4]
    pred123 = as.matrix(KIRCdata_test[, 1:3]) %*% coef123[1:3] + coef123[4]
    pred13 = as.matrix(KIRCdata_test[, 1:3]) %*% coef13[1:3] + coef13[4]
    
    acc1 = mean((log(KIRCdata_test$days) - pred1) ^ 2)
    acc12 = mean((log(KIRCdata_test$days) - pred12) ^ 2)
    acc123 = mean((log(KIRCdata_test$days) - pred123) ^ 2)
    acc13 = mean((log(KIRCdata_test$days) - pred13) ^ 2)
    
    result = list()
    result[[1]] = compare.result
    result[[2]] = time
    result[[3]] = c(acc1, acc12, acc123, acc13)
    return(result)
  }
  