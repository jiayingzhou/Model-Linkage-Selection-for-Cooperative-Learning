### R code from vignette source 'Cuts.Rnw'

###################################################
### code chunk number 1: Load Packages
###################################################
# library(BRugs)
library(coda)
library(RColorBrewer)

library(coda)
library(rjags)
library(ggplot2)
library(plyr)
library(reshape2)
library(stats)
require(graphics)

###################################################
### code chunk number 2: Data
###################################################
nhpv <- c(7, 6, 10, 10, 1, 1, 10, 4, 35, 0, 10, 8, 4)
Npart <- c(111, 71, 162, 188, 145, 215, 166, 37, 173,
           143, 229, 696, 93)
ncases <- c(16, 215, 362, 97, 76, 62, 710, 56, 133,28, 62, 413, 194)
Npop <- c(26983, 250930, 829348, 157775, 150467, 352445, 553066,
          26751, 75815, 150302, 354993, 3683043, 507218)/1000
# ite = 1
# filenames <- paste0("/Users/jiayingzhou/Desktop/model_linkage_exp/exp2_small/",ite-1,".csv")
# data = read.csv(filenames, header = FALSE)
# data = as.matrix(data)
# 
# nhpv = data[1,]
# y1_p_vec = rep(0.1,13)
# Npart = data[2,]
# 
# ncases = data[3,]
# Npop = data[4,]



update.p <- function(Y1, X1) {
  
  shape1 <- 1 + Y1
  shape2 <- 1 + (X1 - Y1)
  
  rbeta(length(shape1), shape1, shape2)
}
# 
# 
# ###################################################
# ### code chunk number 11: Poisson log likelihood
# ###################################################
poisson.loglik <- function(X2, Y2, theta2, p)
{
  mean <- X2 *  (p * theta2)
  sum(dpois(Y2, mean, log=TRUE))
}
# 
# 

# ###################################################
# ### code chunk number 13: Updater for theta2
# ###################################################
update.theta2 <- function(X2, Y2, theta2, p, STEP)
{
  logdensity <- function(b) {
    poisson.loglik(X2, Y2, b, p)
  }
  
  logdensity0 <- logdensity(theta2)
  theta2.new <- -Inf
  while (theta2.new <= 0){
    theta2.new <- theta2 + rnorm(1, mean=0, sd=STEP)
  }
  # print(theta2.new)
  logdensity1 <- logdensity(theta2.new)
  
  R <- exp(logdensity1 - logdensity0)
  if (runif(1) < R) list("theta2" = theta2.new, "accept" = 1) else list("theta2" = theta2, "accept" = 0)
}
# 

###################################################
### code chunk number 14: Tempered
###################################################
sample.temper <- function(X1, Y1, X2, Y2, niter, step.theta2=1, ntemper=1)
{
  theta2 <- rgamma(1, 5, 1)
  p <- rep(13, 0.5)
  
  theta2.samples <- numeric(niter)
  # pall.samples <- matrix(NA, nrow = niter, ncol = 13)
  accept_ratio = 0
  for (i in 1:niter) {
    
    p.old <- p
    p.new <- update.p(Y1, X1)
    for (t in 1:ntemper) {
      pt <- ((ntemper - t) * p.old + t * p.new) / ntemper
      res <- update.theta2(X2, Y2, theta2, pt, step.theta2)
      theta2 <- res$theta2
      accept <- res$accept
      accept_ratio <- accept_ratio + accept
    }
    p <- p.new
    
    # print(accept_ratio)
    
    
    theta2.samples[i] <- theta2
    # pall.samples[i,] <- p
  }
  accept_ratio = accept_ratio/(niter*ntemper)
  
  list("theta2" = theta2.samples, "accept_ratio"=accept_ratio)
}


###################################################
### code chunk number 15: Function to run tempered sampler
###################################################
run.temper <- function(X1, Y1, X2, Y2, nsim=1000, nburnin=1500, seed=121876) {
  
  set.seed(seed)
  
  # Nstep <- 8
  Nstep <- 1
  
  #Based on pilot runs, we set thinning interval to get approximately
  #independent samples from each chain (and hence the same effective
  #sample size).
  # thin <- c(50, 30, 12, 6, 3, 2, 2, 1)
  thin <- c(1)
  
  theta2.samples <- vector("list", Nstep)
  # pall.samples <- vector("list", Nstep)
  for (t in 1:Nstep) {
    # ntemper <- 2^(t-1)
    ntemper <- 2^(7)
    new.samp <- sample.temper(X1, Y1, X2, Y2, thin[t] * (nsim + nburnin), ntemper=ntemper)
    
    
    theta2 <- as.mcmc(new.samp$theta2)
    theta2 <- window(theta2, start=nburnin * thin[t] + 1, thin=thin[t])
    theta2.samples[[t]] <- theta2
  }
  
  list(theta2=theta2.samples,accept_ratio=new.samp$accept_ratio)
}


###################################################
### code chunk number 16: Plot function for tempered sampler
###################################################
plot.temper <- function(s) {
  
  plot(density(s[[1]], bw="nrd"), type = "n", main="", 
       xlab=expression(theta[2]))
  Nstep <- length(s)
  for (t in 1:Nstep) {
    lines(density(s[[t]], bw="nrd"), col=grey(1 - t/Nstep), lwd=2)
  }
  legend("topright", col=grey(1 - (1:Nstep)/Nstep), lty=1, lwd=2,
         legend=formatC(2^(0:(Nstep-1)), width=2), title="Steps")
}


###################################################
### code chunk number 17: Generate tempered samples
###################################################
tempered.samples <- run.temper(X1=Npart, Y1=nhpv, X2=Npop, Y2=ncases)
plot.temper(tempered.samples$theta2)




