library(coda)
library(rjags)
library(ggplot2)
library(plyr)
library(reshape2)
library(stats)
require(graphics)


######## SIMILATED DATA    #########
ite_times=10
test_log_likeli_combine = rep(NA,ite_times)
test_log_likeli_single = rep(NA,ite_times)
test_lilkeli_pull = rep(NA,ite_times)

test_log_likeli_combine2 = rep(NA,ite_times)
test_log_likeli_single2 = rep(NA,ite_times)
test_lilkeli_pull2 = rep(NA,ite_times)

connect_all = 0
for (ite in 1:ite_times) {
  # set.seed(ite)
  # n=13
  # x1vec = c(911,634,570,3260,802,1490,830,711,518,755,678,1601,812)
  # y1_p_vec = c(3.5,0.0,4.3,1.4,6.3,8.5,6.2,5.3,0.7,0.5,6.0,10.8,20.2)/100
  # y1vec = rbinom(n,x1vec,y1_p_vec)
  # 
  # t2 = 500
  # 
  # x2vec = c(5,5,5,5,5,5,2,4,5,5,4,5,4)
  # lam = c(17.5,18.6,38.2,11.2,59.3,85.7,43.6,61.5,50.5,17.6,128.4,231.5,175.4)
  # y2vec = rpois(n,lam)
  # connect=0
  
  
  filenames <- paste0("exp_small/",ite-1,".csv")
  data = read.csv(filenames, header = FALSE)
  data = as.matrix(data)
  connect  = data[5,1]
  connect_all = connect_all + connect
  x1vec = data[1,]
  y1_p_vec = rep(0.1,13)
  y1vec = data[2,]
  
  x2vec = data[3,]
  y2vec = data[4,]
  
  
  d = data.frame(x1vec,y1vec,x2vec,y2vec)
  
  #  test
  
  # test part
  ntest=1000
  y1_mat_test = matrix(NA, nrow = ntest, ncol = 13)
  y2_mat_test = matrix(NA, nrow = ntest, ncol = 13)
  x = 1000
  
  for (jj in 1:13){
    x1vec_test = rep(x,ntest)
    y1_p_vec_test = rep(y1_p_vec[jj], ntest)
    y1vec_test = rbinom(ntest,x1vec_test,y1_p_vec_test)
    y1_mat_test[,jj] = y1vec_test
  }
  
  for (jj in 1:13){
    x2vec_test = rep(100,ntest)
    y1_p_vec_test = rep(y1_p_vec[jj], ntest)
    o2 = 10
    y2vec_test = rpois(ntest,x2vec_test*y1_p_vec_test*o2)
    y2_mat_test[,jj] = y2vec_test
  }
  
  prior=list(alpha = 1, beta = 1)
  model = " model {
  for (i in 1:n) {
  y1vec[i] ~ dbinom(t1[i],x1vec[i])
  y2vec[i]~ dpois((t1[i]*t2)*x2vec[i])
  t1[i] ~ dbeta(alpha,beta)
  }
  t2 ~ dgamma(5,1)
  }
  "
  dat = c(list(n=nrow(d),y1vec=d$y1vec,x1vec=d$x1vec,y2vec=d$y2vec,x2vec=d$x2vec), prior)
  m = jags.model(textConnection(model), dat, n.chains=3)
  
  result = coda.samples(m, c("t1","t2"), 2000) #gelman.diag(res)
  #sm = summary(res)
  dr = ldply(result, function(x) {as.data.frame(x)})
  
  dens1 <- density(dr$`t1[1]`) # returns the density data
  #dens <- density(dr$t2) # returns the density data
  data_true= data.frame(dens1$x,dens1$y)
  plot(data_true,type = "l") # plots the results
  
  
  #  calculate test log likelihood for learner 1
  test_lilkeli = 0
  for (j in 1:13){
    for (i in 1:ntest) {
      mean_likeli = log(mean((dbinom(y1_mat_test[i,j],x1vec_test[i], dr[,j]))))
      test_lilkeli = test_lilkeli + mean_likeli
    }
  }
  test_lilkeli_combine= test_lilkeli/(ntest*13)
  print(test_lilkeli_combine)
  
  #  calculate test log likelihood for learner 2
  test_lilkeli2 = 0
  for (j in 1:13){
    for (i in 1:ntest) {
      mean_likeli = log(mean((dpois(y2_mat_test[i,j],x2vec_test[i]*dr[,j]*dr$t2))))
      test_lilkeli2 = test_lilkeli2 + mean_likeli
    }
  }
  test_lilkeli_combine2 = test_lilkeli2/(ntest*13)
  print(test_lilkeli_combine2)
  
  
  
  
  ##################### single   1
  d1 = d
  prior=list(alpha = 1, beta = 1)
  model1 = " model {
for (i in 1:n) {
y1vec[i] ~ dbinom(t1[i],x1vec[i])
t1[i] ~ dbeta(alpha,beta)
}
}
"
dat1 = c(list(n=nrow(d),y1vec=d1$y1vec,x1vec=d1$x1vec), prior)
m1 = jags.model(textConnection(model1), dat1, n.chains=3)

result1 = coda.samples(m1, c("t1"), 2000) #gelman.diag(res)
#sm = summary(res)
dr1 = ldply(result1, function(x) {as.data.frame(x)})

#dens1 <- density(dr1$`t1`) # returns the density data
dens1 <- density(dr1$`t1[1]`) # returns the density data
data_true1= data.frame(dens1$x,dens1$y)
plot(data_true1,type = "l") # plots the results


#  calculate test log likelihood
test_lilkeli = 0
for (j in 1:13){
  for (i in 1:ntest) {
    mean_likeli = log(mean((dbinom(y1_mat_test[i,j],x1vec_test[i], dr1[,j]))))
    test_lilkeli = test_lilkeli + mean_likeli
  }
}
test_lilkeli_single= test_lilkeli/(ntest*13)
print(test_lilkeli_single)


####   Single  2
prior=list(alpha = 1, beta = 1)
model = " model {
  for (i in 1:n) {
  y2vec[i]~ dpois((t1[i]*t2)*x2vec[i])
  t1[i] ~ dbeta(alpha,beta)
  }
  t2 ~ dgamma(5,1)
  }
  "
dat = c(list(n=nrow(d),y2vec=d$y2vec,x2vec=d$x2vec), prior)
m = jags.model(textConnection(model), dat, n.chains=3)

result = coda.samples(m, c("t1","t2"), 2000) #gelman.diag(res)
#sm = summary(res)
dr2 = ldply(result, function(x) {as.data.frame(x)})

#  calculate test log likelihood for learner 2
test_lilkeli2 = 0
for (j in 1:13){
  for (i in 1:ntest) {
    mean_likeli2 = log(mean((dpois(y2_mat_test[i,j],x2vec_test[i]*dr2[,j]*dr2$t2))))
    test_lilkeli2 = test_lilkeli2 + mean_likeli2
  }
}
test_lilkeli_single2 = test_lilkeli2/(ntest*13)
print(test_lilkeli_single2)




test_lilkeli_pull[ite] = test_lilkeli_combine
test_lilkeli_pull2[ite] = test_lilkeli_combine2
if (connect==0){
  test_lilkeli_combine = test_lilkeli_single
  test_lilkeli_combine2 = test_lilkeli_single2
}

test_log_likeli_combine[ite] = test_lilkeli_combine
test_log_likeli_single[ite] = test_lilkeli_single
test_log_likeli_combine2[ite] = test_lilkeli_combine2
test_log_likeli_single2[ite] = test_lilkeli_single2
}

print(mean(test_lilkeli_pull))
print(mean(test_log_likeli_combine))
print(mean(test_log_likeli_single))
print(sd(test_lilkeli_pull)/sqrt(ite_times))
print(sd(test_log_likeli_combine)/sqrt(ite_times))
print(sd(test_log_likeli_single)/sqrt(ite_times))


print(mean(test_lilkeli_pull2))
print(mean(test_log_likeli_combine2))
print(mean(test_log_likeli_single2))
print(sd(test_lilkeli_pull2)/sqrt(ite_times))
print(sd(test_log_likeli_combine2)/sqrt(ite_times))
print(sd(test_log_likeli_single2)/sqrt(ite_times))



