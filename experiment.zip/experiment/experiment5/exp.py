import random
import time
import pickle
import scipy
from scipy.integrate import quad, dblquad
from scipy import integrate
import numpy as np
import argparse
from scipy.stats import binom, beta, norm, poisson, gamma, uniform
import argparse
from csv import writer
import csv
a = 1
b = 1
mu = 0
sigma = 10
low = 0
up = np.inf
parser = argparse.ArgumentParser()
parser.add_argument('--num11', help='number in x11', default=1000, type=int)
parser.add_argument('--num21', help='number in x21', default=400, type=int)
parser.add_argument('--num31', help='number in x31', default=400, type=int)
parser.add_argument('--seed', help='random seed', default=0, type=int)

args = parser.parse_args()
num11 = args.num11
num21 = args.num21
num31 = args.num31
seed_run = args.seed


def lam(theta_1, theta_2, X2):
    lmda = (theta_1 * theta_2) * X2
    return lmda


def binomial(theta_1, Y1, X1):
    return binom.pmf(Y1, X1, theta_1)


def theta1_pdf(theta):
    return beta.pdf(theta, a, b)

def beta12_pdf(theta):
    # return norm.pdf(theta, 0, 1)
    return gamma.pdf(theta, 5, 1)
    # return beta.pdf(theta, a, b)
    # return uniform.pdf(theta, low, up)

def normal_pdf(theta):
    return norm.pdf(theta, mu, sigma)


def poisson_pmf(lmda, Y2):
    return poisson.pmf(Y2, lmda)


def marg1(theta, X, Y):
    return binomial(theta, Y, X) * theta1_pdf(theta)


def marg2(theta, beta1, X, Y):
    lmda = lam(theta, beta1, X)
    return poisson_pmf(lmda, Y) * theta1_pdf(theta) * beta12_pdf(beta1)


def marg12(theta, beta1,X1, Y1, X2, Y2):
    lmda = lam(theta, beta1, X2)
    return binomial(theta, Y1, X1) * poisson_pmf(lmda, Y2) * theta1_pdf(theta) * beta12_pdf(beta1)


#  calculate marginal likelihood of 1,2

def marginal12_t2(t_2, X11, Y11, X12, Y12):
    f = lambda t_1, t_2, X11, Y11, X12, Y12: marg12(t_1, t_2, X11, Y11, X12, Y12)
    ans = integrate.quad(f, 0, 1, args=(t_2, X11, Y11, X12, Y12))
    return ans
def marginal12(X11, Y11, X12, Y12):
    f = lambda t_2, X11, Y11, X12, Y12: marginal12_t2(t_2, X11, Y11, X12, Y12)[0]
    ans = integrate.quad(f, low, up, args=(X11, Y11, X12, Y12))
    return ans

#  calculate marginal likelihood of 2
def marginal2_t2(t_2, X12, Y12):
    f = lambda t_1, t_2,X12, Y12: marg2(t_1, t_2, X12, Y12)
    ans = integrate.quad(f, 0, 1, args=(t_2, X12, Y12))
    return ans
def marginal2(X12, Y12):
    f = lambda t_2,X12, Y12: marginal2_t2(t_2, X12, Y12)[0]
    ans = integrate.quad(f, low, up, args=(X12, Y12))
    return ans


def marginal_group2(X2, Y2):
    X20, X21, X22, X23, X24, X25, X26, X27, X28, X29, X210, X211, X212 = X2
    Y20, Y21, Y22, Y23, Y24, Y25, Y26, Y27, Y28, Y29, Y210, Y211, Y212 = Y2
    f = lambda t_2, X20,Y20,X21,Y21,X22,Y22,X23,Y23,X24,Y24,X25,Y25,X26,Y26,X27,Y27,X28,Y28,X29,Y29, X210, Y210, X211, Y211, X212, Y212: \
        marginal2_t2(t_2, X20, Y20)[0] * marginal2_t2(t_2, X21, Y21)[0] *marginal2_t2(t_2, X22, Y22)[0] * marginal2_t2(t_2, X23, Y23)[0] * \
        marginal2_t2(t_2, X24, Y24)[0] * marginal2_t2(t_2, X25, Y25)[0] *marginal2_t2(t_2, X26, Y26)[0] * marginal2_t2(t_2, X27, Y27)[0] *\
        marginal2_t2(t_2, X28, Y28)[0] * marginal2_t2(t_2, X29, Y29)[0] * marginal2_t2(t_2, X210, Y210)[0] * marginal2_t2(t_2, X211, Y211)[0] * marginal2_t2(t_2, X212, Y212)[0]
    ans = integrate.quad(f, low, up, args=(X20,Y20,X21,Y21,X22,Y22,X23,Y23,X24,Y24,X25,Y25,X26,Y26,X27,Y27,X28,Y28,X29,Y29, X210, Y210, X211, Y211,X212,Y212))
    return ans

def marginal_group12(X1, Y1, X2, Y2):
    X10, X11, X12, X13, X14, X15, X16, X17, X18, X19, X110, X111, X112 = X1
    Y10, Y11, Y12, Y13, Y14, Y15, Y16, Y17, Y18, Y19, Y110, Y111, Y112 = Y1

    X20, X21, X22, X23, X24, X25, X26, X27, X28, X29, X210, X211, X212 = X2
    Y20, Y21, Y22, Y23, Y24, Y25, Y26, Y27, Y28, Y29, Y210, Y211, Y212 = Y2
    f = lambda t_2, X10, Y10, X11, Y11, X12, Y12, X13, Y13, X14, Y14, X15, Y15, X16, Y16, X17, Y17, X18, Y18, X19, Y19, X110, Y110, X111, Y111,X112,Y112,\
               X20, Y20, X21, Y21, X22, Y22, X23, Y23, X24, Y24, X25, Y25, X26, Y26, X27, Y27, X28, Y28, X29, Y29,  X210, Y210, X211, Y211,X212,Y212: \
    marginal12_t2(t_2, X10, Y10, X20, Y20)[0] * marginal12_t2(t_2, X11, Y11, X21, Y21)[0] * marginal12_t2(t_2, X12, Y12, X22, Y22)[0] * \
    marginal12_t2(t_2,X13, Y13, X23, Y23)[0] * marginal12_t2(t_2, X14, Y14, X24, Y24)[0] * marginal12_t2(t_2, X15, Y15, X25, Y25)[0] * \
    marginal12_t2(t_2,X16, Y16, X26, Y26)[0] * marginal12_t2(t_2, X17, Y17, X27, Y27)[0] * marginal12_t2(t_2, X18, Y18,X28, Y28)[0] * \
    marginal12_t2(t_2, X19, Y19,X29, Y29)[0] * marginal12_t2(t_2, X110, Y110, X210, Y210)[0] * marginal12_t2(t_2, X111, Y111,X211, Y211)[0] * \
    marginal12_t2(t_2, X112, Y112,X212, Y212)[0]
    ans = integrate.quad(f, low, up, args=(
    X10,Y10,X11,Y11,X12,Y12,X13,Y13,X14,Y14,X15,Y15,X16,Y16,X17,Y17,X18,Y18,X19,Y19, X110, Y110, X111, Y111,X112,Y112, \
    X20, Y20, X21, Y21, X22, Y22, X23, Y23, X24, Y24, X25, Y25, X26, Y26, X27, Y27, X28, Y28, X29, Y29,  X210, Y210, X211, Y211,X212,Y212))
    return ans


def marginal1(X11, Y11):
    f = lambda t_1, X11, Y11: marg1(t_1, X11, Y11)
    ans = integrate.quad(f, 0, 1, args=(X11, Y11))
    return ans





def run(seed, real=False):
    size = 13
    connection = 0
    # args = parser.parse_args()
    # np.random.seed(args.seed)
    np.random.seed(seed)
    o1 = np.array([0.1]*size)
    # o1 = np.arange(0.05, 0.70, 0.05)
    o2 = 10
    if not real:
        X1 = np.array([200]+[200]*(size-1))
        Y1 = np.random.binomial(X1, o1, size=size)


        X2 = np.array([10]*size)
        # X2 = np.arange(5, 18, 1)
        Y2 = np.random.poisson(lam=lam(o1, o2,  X2), size=size) + np.arange(5, 70, 5)

    if real:
        # X1 = np.array([911, 634, 570, 3260, 802, 1490, 830, 711, 518, 755, 678, 1601, 812])
        # y1_p_vec = np.array([3.5, 0.0, 4.3, 1.4, 6.3, 8.5, 6.2, 5.3, 0.7, 0.5, 6.0, 10.8, 20.2])
        # Y1 = np.array([31, 0, 24, 45, 50, 126, 51, 37, 3, 3, 40, 172, 164])
        # X2 = np.array([5, 5, 5, 5, 5, 5, 2, 4, 5, 5, 4, 5, 4])
        # Y2 = np.array([17, 18, 38, 11, 59, 85, 43, 61, 50, 17, 128, 231, 175])

        X1 = np.array([911, 634, 570, 3260, 802, 1490, 830, 711, 518, 755, 678, 1601, 812])
        y1_p_vec = np.array([0.017, 0.007, 0.0346, 0.009, 0.0486, 0.0687, 0.0753, 0.062, 0.033, 0.011, 0.083, 0.133, 0.161])
        np.random.seed(seed)
        Y1 = np.random.binomial(X1, y1_p_vec, size=size)
        X2 = np.array([5, 5, 5, 5, 5, 5, 2, 4, 5, 5, 4, 5, 4])*100
        lamda = lam(y1_p_vec, 2.918, X2)
        Y2 = np.random.poisson(lam=lamda, size=size)


    tic = time.time()
    # ans12 = marginal12(X11, Y11, X12, Y12)
    ans12 = marginal_group2(X2, Y2)[0]
    print(ans12)
    ans11 = 1
    for idx in range(size):
        X1_chosed = X1[idx]
        Y1_chosed = Y1[idx]
        ans11 = ans11 * marginal1(X1_chosed, Y1_chosed)[0]
    print(ans11)


    ans_1_all = marginal_group12(X1, Y1, X2, Y2)[0]
    print(ans_1_all)
    ratio1 = ans_1_all / (ans11 * ans12)
    if ratio1 > 1:
        connection = 1
    print(connection)
    with open('exp2_real_inv/'+str(seed)+'.csv', 'a') as f_object:

        # Pass this file object to csv.writer()
        # and get a writer object
        writer_object = writer(f_object)

        # Pass the list as an argument into
        # the writerow()
        writer_object.writerow(list(X1))
        writer_object.writerow(list(Y1))
        writer_object.writerow(list(X2))
        writer_object.writerow(list(Y2))
        writer_object.writerow(list([connection]))
        # Close the file object
        f_object.close()
    return connection

def main():
    seed = seed_run
    result = np.array([0])
    for i in range(20*seed, 20*(seed+1)):
        print('This is iteration ', i)
        connection = run(i, real=True)
        result = np.concatenate((result, [connection]), axis=0)
    result = result[1:]
    return result, seed




if __name__ == '__main__':
    result, seed = main()
    f = open('result/exp2_nocol'+str(seed), 'wb')
    pickle.dump(result, f)
    f.close()








