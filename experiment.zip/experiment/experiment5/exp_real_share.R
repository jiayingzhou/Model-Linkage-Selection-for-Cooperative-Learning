library(coda)
library(rjags)
library(ggplot2)
library(plyr)
library(reshape2)
library(stats)
require(graphics)
source("/Users/jiayingzhou/Desktop/model_linkage_exp/cut_linear.R")
# Y1 ~ Boniomial(X1, theta_{1,i})
# Y2 ~ Poisson(exp(beta1+beta2*theta1_i)*X2)

y1vec_real <- c(7, 6, 10, 10, 1, 1, 10, 4, 35, 0, 10, 8, 4)
x1vec_real <- c(111, 71, 162, 188, 145, 215, 166, 37, 173,
           143, 229, 696, 93)
y2vec_real <- c(16, 215, 362, 97, 76, 62, 710, 56, 133,28, 62, 413, 194)
x2vec_real <- c(26983, 250930, 829348, 157775, 150467, 352445, 553066,
          26751, 75815, 150302, 354993, 3683043, 507218)/1000
iteration = 100
test_result_mat = matrix(NA, iteration, 4)
likeli_cand_mat = matrix(NA, iteration, 3)
algo_vec = rep(NA, iteration)
for (ite in 1:iteration){
  print("this is ite ")
  print(ite)
  filenames <- paste0("exp_real_share/",ite-1,".csv")
  data = read.csv(filenames, header = FALSE)
  data = as.matrix(data)
  connect  = data[6,1]
  marg = data[5,]
  marg1 = marg[1]
  marg2 = marg[2]
  marg12 = marg[3]
  
  x1vec = data[1,]
  y1_p_vec = y1vec_real / x1vec_real
  o2 = 10.05718
  y1vec = data[2,]
  x2vec = data[3,]
  y2vec = data[4,]
  
  # divide all data into two groups
  # Split Data into Training and Testing in R 
  sample_size = floor(0.5*length(x1vec))
  set.seed(ite)
  
  # randomly split data in r
  picked = sample(seq_len(length(x1vec)),size = sample_size)
  x1vec_a = x1vec[picked]
  y1vec_a = y1vec[picked]
  x2vec_a = x2vec[picked]
  y2vec_a = y2vec[picked]
  
  x1vec_b = x1vec[-picked]
  y1vec_b = y1vec[-picked]
  x2vec_b = x2vec[-picked]
  y2vec_b = y2vec[-picked]
  
  
  d = data.frame(x1vec,y1vec,x2vec,y2vec)
  
  nsimulation = 3000
  # get cut samples for theta_2 first
  cut.samples <- run.temper(X1=x1vec, Y1=y1vec, X2=x2vec_a, Y2=y2vec_a, nsim = nsimulation)
  cut.theta2 = cut.samples$theta2
  
  # get samples for theta_1i for all samples
  prior=list(alpha = 1, beta = 1)
  model1 = " model {
  for (i in 1:n) {
  y1vec[i] ~ dbinom(t1[i],x1vec[i])
  t1[i] ~ dbeta(alpha,beta)
  }
  }
  "
  dat1 = c(list(n=nrow(d),y1vec=d$y1vec,x1vec=d$x1vec), prior)
  m1 = jags.model(textConnection(model1), dat1, n.chains=3)
  
  result1 = coda.samples(m1, c("t1"), nsimulation) #gelman.diag(res)
  #sm = summary(res)
  dr1 = ldply(result1, function(x) {as.data.frame(x)})
  
  y2_b_lilkeli = 0
  for (j in 1:nsimulation){
    a = x2vec_b*dr1[j,-picked]*cut.theta2[[1]][j]
    mean_likeli = prod(dpois(y2vec_b,as.numeric(a)))
    y2_b_lilkeli = y2_b_lilkeli + mean_likeli
  }
  y2_b_lilkeli = log(y2_b_lilkeli/nsimulation)
  print(y2_b_lilkeli)
  
  
  # full posterior for y2_a
  
  # d_a = data.frame(x1vec_a,y1vec_a,x2vec_a,y2vec_a)
  # prior=list(alpha = 1, beta = 1)
  # model1_a = " model {
  #   for (i in 1:n) {
  #   y1vec[i] ~ dbinom(t1[i],x1vec[i])
  #   t1[i] ~ dbeta(alpha,beta)
  #   }
  #   }
  #   "
  # dat1_a = c(list(n=nrow(d_a),y1vec=d_a$y1vec_a,x1vec=d_a$x1vec_a), prior)
  # m1_a = jags.model(textConnection(model1_a), dat1_a, n.chains=3)
  # 
  # result1_a = coda.samples(m1_a, c("t1"), nsimulation) #gelman.diag(res)
  # #sm = summary(res)
  # dr1_a = ldply(result1_a, function(x) {as.data.frame(x)})
  
  theta2_sample = rgamma(nsimulation, 5, 1)
  
  y2_a_likeli = 0
  for (j in 1:nsimulation){
    a = x2vec_a*dr1[j,picked]*theta2_sample[j]
    mean_likeli = prod(dpois(y2vec_a,as.numeric(a)))
    y2_a_likeli = y2_a_likeli + mean_likeli
  }
  y2_a_likeli = log(y2_a_likeli/nsimulation)
  print(y2_a_likeli)
  
  log_y2_cut_marg = y2_a_likeli + y2_b_lilkeli 
  print(log_y2_cut_marg)
  
  
  
  
  
  
  #  p(y2|y1)
  
  prior=list(alpha = 1, beta = 1)
  model = " model {
  for (j in 1:n1){
  y2vec[j]~ dpois((t1[j]*t2)*x2vec[j])
  y1vec[j] ~ dbinom(t1[j],x1vec[j])
  t1[j] ~ dbeta(alpha,beta)
  }
  t2 ~ dgamma(5,1)
  }
  "
  dat = c(list(n1=6, y1vec=y1vec_a,x1vec=x1vec_a,y2vec=y2vec_a,x2vec=x2vec_a), prior)
  m = jags.model(textConnection(model), dat, n.chains=3)
  
  result = coda.samples(m, c("t1","t2"), nsimulation) #gelman.diag(res)
  #sm = summary(res)
  dr = ldply(result, function(x) {as.data.frame(x)})
  
  # y2_likeli = 0
  # for (j in 1:nsimulation){
  #   a = x2vec*dr1[j,1:13]*theta2_sample[j]
  #   mean_likeli = prod(dpois(y2vec,as.numeric(a)))
  #   y2_likeli = y2_likeli + mean_likeli
  # }
  # y2_likeli = log(y2_likeli/nsimulation)
  # print(y2_likeli)
  
  y2_b_lilkeli_all = 0
  for (j in 1:nsimulation){
    a = x2vec_b*dr1[j,-picked]*dr$t2[j]
    mean_likeli = prod(dpois(y2vec_b,as.numeric(a)))
    y2_b_lilkeli_all = y2_b_lilkeli_all + mean_likeli
  }
  y2_b_lilkeli_all = log(y2_b_lilkeli_all/nsimulation)
  print(y2_b_lilkeli_all)
  
  log_y2_condition_marg = y2_a_likeli + y2_b_lilkeli_all
  print(log_y2_condition_marg)
  
  # p(y2)
  
  # (i) 𝑋∼Beta(𝑎,𝑏)
  # (ii) 𝑌∼ Gamma(𝑎+𝑏,𝑐)
  # (iii) 𝑋𝑌∼ Gamma(𝑎,𝑐)
  
  # nsimulation = 2000000
  # theta_sample = matrix(NA, nsimulation, 13)
  # for (jj in 1:13) {
  #   theta_sample[,jj] = runif(nsimulation, 0, 2)
  # }
  # y2_likeli_s = 0
  # for (j in 1:nsimulation){
  #   a = x2vec*theta_sample[j,1:13]
  #   mean_likeli = prod(dpois(y2vec,as.numeric(a)))
  #   y2_likeli_s = y2_likeli_s + mean_likeli
  # 
  # }
  # y2_likeli_s = log(y2_likeli_s/nsimulation)
  # print(y2_likeli_s)
  
  log_y2_likeli_s = marg2
  
  # compare y2_likeli_cut, y2_likeli_all, y2_likeli_single
  
  likeli_cand = c(log_y2_cut_marg, log_y2_condition_marg, log_y2_likeli_s)
  mode_vec = c("cut", "connect", "single")
  mode = mode_vec[which.max(likeli_cand)]
  
  
  #############      TEST      ############
  
  # test part
  ntest=1000
  y1_mat_test = matrix(NA, nrow = ntest, ncol = 13)
  y2_mat_test = matrix(NA, nrow = ntest, ncol = 13)
  x = 1000
  
  for (jj in 1:13){
    x1vec_test = rep(x,ntest)
    y1_p_vec_test = rep(y1_p_vec[jj], ntest)
    y1vec_test = rbinom(ntest,x1vec_test,y1_p_vec_test)
    y1_mat_test[,jj] = y1vec_test
  }
  
  for (jj in 1:13){
    x2vec_test = rep(100,ntest)
    y1_p_vec_test = rep(y1_p_vec[jj], ntest)
    y2vec_test = rpois(ntest,lambda = x2vec_test*y1_p_vec_test*o2)
    y2_mat_test[,jj] = y2vec_test
  }
  
  #  test use cut distribution
  
  cut.samples <- run.temper(X1=x1vec, Y1=y1vec, X2=x2vec, Y2=y2vec, nsim = nsimulation)
  cut.theta2 = cut.samples$theta2
  
  #  calculate test log likelihood for learner 2
  test_lilkeli2_cut = 0
  for (j in 1:13){
    for (i in 1:ntest) {
      mean_likeli = log(mean((dpois(y2_mat_test[i,j],x2vec_test[i]*dr1[,j]*cut.theta2[[1]]))))
      test_lilkeli2_cut = test_lilkeli2_cut + mean_likeli
    }
  }
  test_lilkeli2_cut = test_lilkeli2_cut/(ntest*13)
  print(test_lilkeli2_cut)
  
  if (mode == "cut"){
    test_lilkeli2_algo = test_lilkeli2_cut
  }
  
  
  
  # test use full posterior
  prior=list(alpha = 1, beta = 1)
  model_all = " model {
for (i in 1:n) {
y1vec[i] ~ dbinom(t1[i],x1vec[i])
t1[i] ~ dbeta(alpha,beta)
}
for (j in 1:n){
y2vec[j]~ dpois((t1[j]*t2)*x2vec[j])
}
t2 ~ dgamma(5,1)
}
"
dat_all = c(list(n=13, y1vec=d$y1vec,x1vec=d$x1vec,y2vec=y2vec,x2vec=x2vec), prior)
m_all = jags.model(textConnection(model_all), dat_all, n.chains=3)

result_all = coda.samples(m_all, c("t1","t2"), nsimulation) #gelman.diag(res)
#sm = summary(res)
dr_all = ldply(result_all, function(x) {as.data.frame(x)})

#  calculate test log likelihood for learner 2
test_lilkeli2_all = 0
for (j in 1:13){
  for (i in 1:ntest) {
    mean_likeli = log(mean((dpois(y2_mat_test[i,j],x2vec_test[i]*dr_all[,j]*dr_all$t2))))
    test_lilkeli2_all = test_lilkeli2_all + mean_likeli
  }
}
test_lilkeli2_all = test_lilkeli2_all/(ntest*13)
print(test_lilkeli2_all)

if (mode == "connect"){
  test_lilkeli2_algo = test_lilkeli2_all
}



# test use single agent

prior=list(alpha = 1, beta = 1)
model2 = " model{
for (j in 1:n){
y2vec[j]~ dpois((t1[j]*t2)*x2vec[j])
t1[j] ~ dbeta(alpha,beta)
}
t2 ~ dgamma(5,1)
}
"
dat2 = c(list(n=13, y2vec=y2vec,x2vec=x2vec), prior)
m2 = jags.model(textConnection(model2), dat2, n.chains=3)

result2 = coda.samples(m2, c("t1","t2"), nsimulation) #gelman.diag(res)
#sm = summary(res)
dr2 = ldply(result2, function(x) {as.data.frame(x)})

#  calculate test log likelihood for learner 2
test_lilkeli2_2 = 0
for (j in 1:13){
  for (i in 1:ntest) {
    mean_likeli = log(mean((dpois(y2_mat_test[i,j],x2vec_test[i]*dr2[,j]*dr2$t2))))
    test_lilkeli2_2 = test_lilkeli2_2 + mean_likeli
  }
}
test_lilkeli2_2 = test_lilkeli2_2/(ntest*13)
print(test_lilkeli2_2)
if (mode == "single"){
  test_lilkeli2_algo = test_lilkeli2_2
}

test_result = c(test_lilkeli2_algo, test_lilkeli2_cut, test_lilkeli2_all, test_lilkeli2_2)

test_result_mat[ite,] = test_result
likeli_cand_mat[ite,] = likeli_cand
algo_vec[ite] = mode
}
mean_result = colMeans(test_result_mat)
se_result = apply(test_result_mat, 2, sd)/sqrt(iteration)

mean_marg = colMeans(likeli_cand_mat)
se_marg = apply(likeli_cand_mat, 2, sd)/sqrt(iteration)
print(mean_result)
print(se_result)
print(mean_marg)
print(se_marg)
print(sum(algo_vec=="cut"))
print(sum(algo_vec=="connect"))
print(sum(algo_vec=="single"))








